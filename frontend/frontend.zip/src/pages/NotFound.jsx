export default function NotFound(){
  return <div className="text-center py-20">Page not found</div>
}
    